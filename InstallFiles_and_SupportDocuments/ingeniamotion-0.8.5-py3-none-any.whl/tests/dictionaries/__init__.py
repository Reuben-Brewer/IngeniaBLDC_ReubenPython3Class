from os.path import abspath, dirname, join

PATH = dirname(abspath(__file__))
VIRTUAL_DRIVE_XDF_PATH = join(PATH, "virtual_drive.xdf")
