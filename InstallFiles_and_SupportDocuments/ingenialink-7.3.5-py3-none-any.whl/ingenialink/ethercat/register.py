from ingenialink.canopen.register import CanopenRegister


class EthercatRegister(CanopenRegister):
    pass
